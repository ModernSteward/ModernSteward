using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ModernSteward;
using System.Speech.Recognition;

namespace ModernSteward
{
    public class CustomPlugin : PluginFunctionality
    {
        public override void Trigger(SemanticValue aSemantics)
        {
            List<KeyValuePair<string, string>> semanticsToDict = new List<KeyValuePair<string, string>>();
            foreach (var s in aSemantics)
            {
                semanticsToDict.Add(new KeyValuePair<string, string>(s.Key.ToString(), s.Value.Value.ToString()));
            }

        }

        public override Grammar GetGrammar()
        {
            Grammar grammarToReturn = 
                new Grammar(ModernSteward.TreeViewToGrammarBuilderAlgorithm.CreateGrammarFromXML(@"CustomPluginGrammar.xml"));
            return grammarToReturn;
        }

        public override void Initialize()
        {
            //Custom initialization for your plugin
        }
    }
}
